<?php
  $config = array(
    'host'        => 'localhost',
    'db_name'     => 'budgetory',
    'db_username' => 'phpuser1',
    'db_password' => 'phppass',
  );
?>